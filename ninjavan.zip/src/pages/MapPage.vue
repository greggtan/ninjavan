<template>
   <div>
      <AddGoogleMap />
   </div>
</template>
 
<script>
import AddGoogleMap from "../components/AddGoogleMap";
 
export default {
  
  components: {
    AddGoogleMap
  }
}
</script>