<template>
  <q-page class="">
      <h1>{{a}}</h1>
  </q-page>
</template>

<script>
export default {
  data () {
    return {
      a:'Help Page'
    }
  },
  
}
</script>
